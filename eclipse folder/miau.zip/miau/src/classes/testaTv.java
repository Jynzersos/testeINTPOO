package classes;

public class testaTv {

	public static void main(String[] args) {
		Tv tv1;
		tv1 = new Tv();
		
		tv1.canal = 9;
		tv1.volume = 36;
		
		tv1.aumentarVolume();
		tv1.aumentarVolume();
		tv1.diminuirVolume();
		tv1.trocarCanal(65);
		
		System.out.println("Dados tv:" + tv1.mostrar());
		
		Tv tv2 = new Tv();
		
		tv2.canal = 150;
		tv2.volume = 3;
		
		tv2.aumentarVolume();
		tv2.aumentarVolume();
		tv2.diminuirVolume();
		tv2.diminuirVolume();
		tv2.diminuirVolume();
		tv2.trocarCanal(80);
		
		System.out.println("Dados tv2:" + tv2.mostrar());
	}

}
