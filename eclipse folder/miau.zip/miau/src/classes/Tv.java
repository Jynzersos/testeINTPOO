package classes;


public class Tv {
	public  int volume;
	public  int canal;
	
	public void aumentarVolume() {
		volume++;
	}
	
	public void diminuirVolume() {
		volume--;
	}
	
	public void trocarCanal(int c) {
		canal = c;
	}
	
	public String mostrar() {
		String mostrar = "Volume: " + volume + "\\nCanal: " + canal;
		return mostrar;
	}
}
